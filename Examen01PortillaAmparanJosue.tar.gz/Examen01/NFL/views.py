# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render

# Create your views here.
def NFLP(request):
	return render(request,'home/NFLP.html')
	
#Equipo Principal
def ParraTeam(request):
	return render(request,'home/ParraTeam.html')

#Equipos NFC Este

def Cowboys(request):
	return render(request,'home/Cowboys.html')

def NewYorkGiants(request):
	return render(request,'home/NewYorkGiants.html')

def PhiladelphiaEagles(request):
	return render(request,'home/PhiladelphiaEagles.html')

def WashingtonRedskins(request):
	return render(request,'home/WashingtonRedskins.html')

#Equipos AFC Este

def Buffalo(request):
	return render(request,'home/Buffalo.html')

def Miami(request):
	return render(request,'home/Miami.html')

def Patriots(request):
	return render(request,'home/Patriots.html')

def Jets(request):
	return render(request,'home/Jets.html')


#Equipos NFC Oeste

def Arizona(request):
	return render(request,'home/Arizona.html')

def SanFrancisco(request):
	return render(request,'home/SanFrancisco.html')

def Seattle(request):
	return render(request,'home/Seattle.html')

def Angeles(request):
	return render(request,'home/Angeles.html')

#Equipos AFC Oeste

def Denver(request):
	return render(request,'home/Denver.html')

def Kansas(request):
	return render(request,'home/Kansas.html')

def Chargers(request):
	return render(request,'home/Chargers.html')

def Oakland(request):
	return render(request,'home/Oakland.html')

#Equipos NFC Norte

def Chicago(request):
	return render(request,'home/Chicago.html')

def Detroit(request):
	return render(request,'home/Detroit.html')

def Green(request):
	return render(request,'home/Green.html')

def Minnesota(request):
	return render(request,'home/Minnesota.html')

#Equimos AFC Norte

def Baltimore(request):
	return render(request,'home/Baltimore.html')

def Cincinnari(request):
	return render(request,'home/Cincinnari.html')

def Cleveland(request):
	return render(request,'home/Cleveland.html')

def Pittsburgh(request):
	return render(request,'home/Pittsburgh.html')

#Equipos NFC Sur

def Atlanta(request):
	return render(request,'home/Atlanta.html')

def Carolina(request):
	return render(request,'home/Carolina.html')

def Orleans(request):
	return render(request,'home/Orleans.html')

def Tampa(request):
	return render(request,'home/Tampa.html')


#Equipos AFC Sur
def Houston(request):
	return render(request,'home/Houston.html')

def Jacksonville(request):
	return render(request,'home/Jacksonville.html')

def Indianapolis(request):
	return render(request,'home/Indianapolis.html')

def Tennessee(request):
	return render(request,'home/Tennessee.html')