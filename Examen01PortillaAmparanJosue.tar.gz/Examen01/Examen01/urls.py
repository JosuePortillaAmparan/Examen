"""Examen01 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from NFLP import views

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^$', views.NFLP, name='NFLP'),

    #Urls para cada vista por equipo
    #Url Equipo Principal
    url(r'^$', view.ParraTeam, name='ParraTeam'),

    #URLS Equipos NFC Este
    url(r'^Cowboys/$', views.Cowboys, name='Cowboys'),
    url(r'^NewYorkGiants/$', views.NewYorkGiants, name='NewYorkGiants'),
    url(r'^PhiladelphiaEagles/$', views.PhiladelphiaEagles, name='PhiladelphiaEagles'),
    url(r'^WashingtonRedskins/$', views.WashingtonRedskins, name='WashingtonRedskins'),

    #URLS Equipos AFC Este

    url(r'^Buffalo/$', views.Buffalo, name='Buffalo'),
    url(r'^Miami/$', views.Miami, name='Miami'),
    url(r'^Patriots/$', views.Patriots, name='Patriots'),
    url(r'^Jets/$', views.Jets, name='Jets'),

    #URLS Equipos NFC Oeste
    url(r'^Arizona/$', views.Arizona, name='Arizona'),
    url(r'^SanFrancisco/$', views.SanFrancisco, name='SanFrancisco'),
    url(r'^Seattle/$', views.Seattle, name='Seattle'),
    url(r'^Angeles/$', views.Angeles, name='Angeles'),

    #URLS Equipos AFC Oeste
    url(r'^Denver/$', views.Denver, name='Denver'),
    url(r'^Kansas/$', views.Kansas, name='Kansas'),
    url(r'^Chargers/$', views.Chargers, name='Chargers'),
    url(r'^Oakland/$', views.Oakland, name='Oakland'),

    #URLS Equipos NFC Norte
    url(r'^Chicago/$', views.Chicago, name='Chicago'),
    url(r'^Detroit/$', views.Detroit, name='Detroit'),
    url(r'^Green/$', views.Green, name='Green'),
    url(r'^Minnesota/$', views.Minnesota, name='Minnesota'),

    #URLS Equimos AFC Norte
    url(r'^Baltimore/$', views.Baltimore, name='Baltimore'),
    url(r'^Cincinnari/$', views.Cincinnari, name='Cincinnari'),
    url(r'^Cleveland/$', views.Cleveland, name='Cleveland'),
    url(r'^Pittsburgh/$', views.Pittsburgh, name='Pittsburgh'),

    #URLS Equipos NFC Sur
    url(r'^Atlanta/$', views.Atlanta, name='Atlanta'),
    url(r'^Carolina/$', views.Carolina, name='Carolina'),
    url(r'^Orleans/$', views.Orleans, name='Orleans'),
    url(r'^Tampa/$', views.Tampa, name='Tampa'),

    #URLS Equipos AFC Sur
    url(r'^Houston/$', views.Houston, name='Houston'),
    url(r'^Jacksonville/$', views.Jacksonville, name='Jacksonville'),
    url(r'^Indianapolis/$', views.Indianapolis, name='Indianapolis'),
    url(r'^Tennessee/$', views.Tennessee, name='Tennessee'),
]
